package com.sbs.example.textBoard;

public class AppConfig {
	public String getSiteName() {
		return "Java's Meow";
	}

	public String getDisqusApiKey() {
		return "qTd9t8o1Z6iggCWednE6phIBAe4ke6c6dPWvIPtnt5pDugtINDsEPLmq0JgKgeyT";
	}

	public String getDisqusForumName() {
		return "ssg-blog";
	}

	public String getGa4PropertyId() {		
		return "256610641";
	}
}
