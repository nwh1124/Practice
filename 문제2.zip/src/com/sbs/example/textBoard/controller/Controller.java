package com.sbs.example.textBoard.controller;

public abstract class Controller {
	public abstract void doCommand(String cmd);
}
